<?php

return [
	"Add block above" => "Block oberhalb hinzuf\xC3\xBCgen",
	"Block type" => "Block-Art",
	"The maximum number of blocks of this type the field is allowed to have." => "Die maximale Anzahl an Bl\xC3\xB6cken dieser Art, die das Feld haben darf.",
	"Child Blocks" => "Kind-Bl\xC3\xB6cke",
	"Which block types do you want to allow as children?" => "Welche Block-Arten m\xC3\xB6chtest Du als Kinder erlauben?",
	"Delete block type" => "Block-Art l\xC3\xB6schen",
	"Delete group" => "Gruppe l\xC3\xB6schen",
	"Top Level" => "Oberste Ebene",
	"Will this block type be allowed at the top level?" => "Soll diese Block-Art f\xC3\xBCr die oberste Ebene erlaubt sein?",
	"Define the types of blocks that can be created within this Neo field, as well as the fields each block type is made up of." => "Definiere die Block-Arten, die dieses Neo-Feld haben darf und die Felder, aus denen jeder Block besteht.",
	"Unable to nest Neo fields." => "Neo-Felder k\xC3\xB6nnen nicht verschachtelt werden.",
	"Duplicate block" => "Block duplizieren",
];
