Sprout Fields!

- Email Field
- Hidden Field
- Invisible Field
- Link Field
- Phone Field

Here are some online resources you might find useful:

Sprout Fields Docs
------------------------------------------------------------
Code examples, tags, common questions:
http://sprout.barrelstrengthdesign.com/craft-plugins/fields


Sprout Fields Updates
------------------------------------------------------------
http://sprout.barrelstrengthdesign.com/craft-plugins/fields/updates


Sprout Fields Support
------------------------------------------------------------
http://sprout.barrelstrengthdesign.com/craft-plugins/request/support


Sprout Fields License Terms
------------------------------------------------------------
Use of Sprout Fields is subject to the license agreement available here:
http://sprout.barrelstrengthdesign.com/license