<?php
namespace Craft;

/**
 * Class Neo_ElementType
 *
 * @package Craft
 */
abstract class Neo_ElementType extends BaseEnum
{
	const NeoBlock = 'Neo_Block';
}
