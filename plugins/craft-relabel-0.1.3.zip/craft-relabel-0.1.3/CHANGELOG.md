## Changelog

#### v0.1.3
- `Improved` Label names and instructions can now be translated
- `Improved` Improved API for plugin use (now supports the Neo plugin)

#### v0.1.2
- `Fixed` Fixed issue where labels weren't getting applied for non-admins (thanks [@gethyn1](https://github.com/gethyn1))

#### v0.1.1
- `Fixed` Fixed issue where labels weren't getting applied on non-single sections with only one entry type

#### v0.1.0
- Initial release
