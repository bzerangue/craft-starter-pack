import Configurator from './configurator/Configurator'
import Input from './input/Input'

window.Neo = {
	Configurator: Configurator,
	Input: Input
}
